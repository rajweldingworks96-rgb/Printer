/**
 * Boundary for Android native printing features.
 *
 * A native implementation can expose:
 * - USB device discovery / permission
 * - IPP/network discovery
 * - Wi-Fi Direct peer discovery
 * - Bluetooth discovery
 * - printer capabilities
 * - job status
 *
 * Keeping this boundary explicit prevents UI code from depending on a
 * particular printer protocol.
 */
export interface PrintBridgeNative {
  discoverUsbPrinters(): Promise<string[]>;
  discoverNetworkPrinters(): Promise<string[]>;
  discoverWifiDirectPrinters(): Promise<string[]>;
  discoverBluetoothPrinters(): Promise<string[]>;
}
