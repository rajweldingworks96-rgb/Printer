export interface PrintHistoryEntry {
  id: string;
  documentName: string;
  printerName: string;
  status: "COMPLETED" | "FAILED";
  timestamp: number;
}

export class PrintHistoryStore {
  private entries: PrintHistoryEntry[] = [];
  add(entry: PrintHistoryEntry) { this.entries.unshift(entry); }
  list() { return [...this.entries]; }
}
