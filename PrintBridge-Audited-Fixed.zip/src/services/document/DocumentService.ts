import type { DocumentPickerAsset } from "expo-document-picker";
import type { DocumentType, PrintDocument } from "../../types/documents";

function typeFromMime(mime?: string): DocumentType {
  if (mime === "application/pdf") return "PDF";
  if (mime?.startsWith("image/")) return "IMAGE";
  if (mime === "text/plain") return "TEXT";
  return "OTHER";
}

export function createDocumentFromPicker(asset: DocumentPickerAsset): PrintDocument {
  return {
    id: asset.uri,
    name: asset.name,
    type: typeFromMime(asset.mimeType),
    pageCount: 0,
    uri: asset.uri,
    sizeBytes: asset.size,
  };
}
