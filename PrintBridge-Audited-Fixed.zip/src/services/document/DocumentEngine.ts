import type { PrintDocument } from "../../types/documents";

export interface DocumentEngine {
  getPageCount(document: PrintDocument): Promise<number>;
  renderPage(document: PrintDocument, page: number): Promise<string>;
}

export class DocumentEnginePlaceholder implements DocumentEngine {
  async getPageCount(document: PrintDocument): Promise<number> { return document.pageCount; }
  async renderPage(): Promise<string> { throw new Error("Native PDF rendering adapter required."); }
}
