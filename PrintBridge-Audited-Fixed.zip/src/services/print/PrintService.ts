import type { PrintDocument } from "../../types/documents";
import type { PrintJobOptions, PrinterDevice } from "../../types/printing";

export interface PrintService {
  print(printer: PrinterDevice, document: PrintDocument, options: PrintJobOptions): Promise<void>;
}

export class PrintServiceRouter implements PrintService {
  async print(): Promise<void> {
    throw new Error("Select a validated printer transport before submitting the job.");
  }
}
