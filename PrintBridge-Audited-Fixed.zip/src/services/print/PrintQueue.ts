export type PrintJobStatus = "QUEUED" | "PRINTING" | "PAUSED" | "COMPLETED" | "FAILED" | "CANCELLED";

export interface PrintQueueJob {
  id: string;
  documentId: string;
  printerId: string;
  status: PrintJobStatus;
  createdAt: number;
  error?: string;
}

export class InMemoryPrintQueue {
  private jobs: PrintQueueJob[] = [];
  add(job: PrintQueueJob) { this.jobs.push(job); }
  list() { return [...this.jobs]; }
  update(id: string, patch: Partial<PrintQueueJob>) {
    this.jobs = this.jobs.map((j) => j.id === id ? { ...j, ...patch } : j);
  }
}
