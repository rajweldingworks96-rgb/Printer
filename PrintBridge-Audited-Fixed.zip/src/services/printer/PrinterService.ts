import type { PrinterConnectionType, PrinterDevice } from "../../types/printing";

export const getAvailableTransports = (): PrinterConnectionType[] =>
  ["USB_OTG", "WIFI", "WIFI_DIRECT", "BLUETOOTH"];

export interface PrinterTransport {
  readonly type: PrinterConnectionType;
  discover(): Promise<PrinterDevice[]>;
  connect(printer: PrinterDevice): Promise<void>;
  disconnect(): Promise<void>;
  isConnected(): Promise<boolean>;
}
