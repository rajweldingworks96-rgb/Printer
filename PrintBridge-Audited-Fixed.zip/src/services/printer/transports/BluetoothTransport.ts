import type { PrinterDevice } from "../../../types/printing";
import type { PrinterTransport } from "../PrinterService";

export class BluetoothTransport implements PrinterTransport {
  readonly type = "BLUETOOTH" as const;
  async discover(): Promise<PrinterDevice[]> { return []; }
  async connect(): Promise<void> { throw new Error("Bluetooth printer protocol adapter requires printer-specific validation."); }
  async disconnect(): Promise<void> {}
  async isConnected(): Promise<boolean> { return false; }
}
