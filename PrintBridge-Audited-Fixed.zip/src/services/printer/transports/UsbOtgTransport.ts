import type { PrinterDevice } from "../../../types/printing";
import type { PrinterTransport } from "../PrinterService";

export class UsbOtgTransport implements PrinterTransport {
  readonly type = "USB_OTG" as const;
  async discover(): Promise<PrinterDevice[]> { return []; }
  async connect(): Promise<void> { throw new Error("Native USB host/protocol adapter must be selected for the connected printer."); }
  async disconnect(): Promise<void> {}
  async isConnected(): Promise<boolean> { return false; }
}
