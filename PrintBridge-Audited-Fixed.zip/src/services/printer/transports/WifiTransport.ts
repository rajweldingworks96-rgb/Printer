import type { PrinterDevice } from "../../../types/printing";
import type { PrinterTransport } from "../PrinterService";

export class WifiTransport implements PrinterTransport {
  readonly type = "WIFI" as const;
  async discover(): Promise<PrinterDevice[]> { return []; }
  async connect(): Promise<void> { throw new Error("Network printer discovery/IPP adapter requires native implementation."); }
  async disconnect(): Promise<void> {}
  async isConnected(): Promise<boolean> { return false; }
}
