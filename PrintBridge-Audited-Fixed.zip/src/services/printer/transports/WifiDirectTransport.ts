import type { PrinterDevice } from "../../../types/printing";
import type { PrinterTransport } from "../PrinterService";

export class WifiDirectTransport implements PrinterTransport {
  readonly type = "WIFI_DIRECT" as const;
  async discover(): Promise<PrinterDevice[]> { return []; }
  async connect(): Promise<void> { throw new Error("Wi-Fi Direct native adapter requires Android implementation."); }
  async disconnect(): Promise<void> {}
  async isConnected(): Promise<boolean> { return false; }
}
