import type { PrinterDevice } from "../../types/printing";

export function supportsAutomaticDuplex(printer: PrinterDevice): boolean {
  return printer.capabilities?.automaticDuplex === true;
}

export function chooseDuplexMode(printer: PrinterDevice, requested: "AUTO" | "MANUAL") {
  if (requested === "AUTO" && supportsAutomaticDuplex(printer)) return "DUPLEX_AUTO" as const;
  return "DUPLEX_MANUAL" as const;
}
