export interface PhysicalSheet {
  sheet: number;
  front: number | 0;
  back: number | 0;
}

export interface ManualDuplexPlan {
  totalPages: number;
  totalSheets: number;
  firstPass: number[];
  secondPass: number[];
  sheets: PhysicalSheet[];
  secondPassReversedForStack: number[];
  summary: string;
}

/**
 * Models a common manual-duplex workflow:
 * first pass prints front pages 1,3,5...
 * the printed stack is physically reversed by the printer/output path,
 * then the second pass is fed with the required order for backs.
 *
 * The exact feed orientation is printer-specific, so the planner exposes
 * the physical sheet mapping rather than hiding that assumption.
 */
export function planManualDuplex(totalPages: number): ManualDuplexPlan {
  const safePages = Math.max(0, Math.floor(totalPages));
  const totalSheets = Math.ceil(safePages / 2);
  const sheets: PhysicalSheet[] = [];

  for (let sheet = 1; sheet <= totalSheets; sheet++) {
    const front = sheet * 2 - 1;
    const back = sheet * 2 <= safePages ? sheet * 2 : 0;
    sheets.push({ sheet, front, back });
  }

  const firstPass = sheets.map((s) => s.front).filter((p) => p > 0);
  const secondPass = sheets.map((s) => s.back).filter((p) => p > 0);

  return {
    totalPages: safePages,
    totalSheets,
    firstPass,
    secondPass,
    sheets,
    secondPassReversedForStack: [...secondPass].reverse(),
    summary: safePages === 0
      ? "No pages."
      : `${safePages} PDF pages → ${totalSheets} sheet(s). First pass: ${firstPass.join(", ")}. Second pass after stack reversal: ${[...secondPass].reverse().join(", ")}.`,
  };
}
