export type DocumentType = "PDF" | "IMAGE" | "TEXT" | "OTHER";

export interface PrintDocument {
  id: string;
  name: string;
  type: DocumentType;
  pageCount: number;
  uri: string;
  sizeBytes?: number;
}
