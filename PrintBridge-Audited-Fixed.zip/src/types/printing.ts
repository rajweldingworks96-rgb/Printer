export type PrinterConnectionType = "USB_OTG" | "WIFI" | "WIFI_DIRECT" | "BLUETOOTH";
export type PrintColorMode = "COLOR" | "MONOCHROME";
export type DuplexMode = "SIMPLEX" | "DUPLEX_AUTO" | "DUPLEX_MANUAL";

export interface PrinterCapabilities {
  color: boolean;
  automaticDuplex: boolean;
  paperSizes: string[];
  mediaTypes: string[];
  maxCopies: number;
}

export interface PrinterDevice {
  id: string;
  name: string;
  connectionType: PrinterConnectionType;
  manufacturer?: string;
  model?: string;
  isReady: boolean;
  capabilities?: PrinterCapabilities;
}

export interface PrintJobOptions {
  copies: number;
  colorMode: PrintColorMode;
  duplexMode: DuplexMode;
  fromPage?: number;
  toPage?: number;
}
