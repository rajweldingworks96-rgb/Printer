# Printer protocol strategy

PrintBridge separates connection from printer language.

Possible paths include:
- Android system Print Framework / print services
- IPP / IPP Everywhere for compatible network printers
- PCL / PostScript where the printer supports it
- ESC/P-family protocols for compatible devices
- vendor-specific protocols where documented

A device is marked supported only when its transport and print language are
known to work. Unsupported combinations produce an explicit compatibility error.
