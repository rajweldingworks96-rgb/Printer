# Smart Manual Duplex specification

Terminology:
- PDF page = logical page in the document
- sheet = one physical paper
- front = first physical side
- back = second physical side
- output stack = the physical order in which sheets leave the printer

For N pages:
- sheet count = ceil(N / 2)
- front pages = 1,3,5,...
- back pages = 2,4,6,...

However, the second-pass order is NOT chosen from page numbers alone. The engine
must model the printer's physical output orientation and the user's feed action.

The planner therefore exposes:
- sheet mapping
- first pass
- second pass
- reversed second-pass order
- blank-side page 0 for an odd final page

Stage 10 should add calibrated profiles for common printer output/feed behaviors
instead of assuming one universal orientation.
