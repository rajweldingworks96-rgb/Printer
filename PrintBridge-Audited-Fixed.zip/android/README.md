# Android native layer

The final Android build should implement this boundary using a native module.

USB/OTG:
- Android USB Host APIs
- USB permission flow
- interface/endpoint discovery
- printer-language/protocol adapter selection

Network:
- IPP where supported
- mDNS/Bonjour-style discovery where available

Bluetooth:
- Android Bluetooth APIs plus a printer protocol adapter where required

Wi-Fi Direct:
- Android Wi-Fi P2P APIs

Do not assume that a USB printer understands raw PDF bytes. Many printers require
PCL, PostScript, ESC/P, vendor languages, or an Android/system printer service.
