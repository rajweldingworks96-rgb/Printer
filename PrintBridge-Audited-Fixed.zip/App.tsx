import { StatusBar } from "expo-status-bar";
import { useMemo, useState } from "react";
import { Alert, Pressable, SafeAreaView, ScrollView, StyleSheet, Text, View } from "react-native";
import * as DocumentPicker from "expo-document-picker";
import { planManualDuplex } from "./src/core/duplex/ManualDuplexEngine";
import { getAvailableTransports } from "./src/services/printer/PrinterService";
import { createDocumentFromPicker } from "./src/services/document/DocumentService";
import type { PrintDocument } from "./src/types/documents";
import type { DuplexMode, PrintColorMode } from "./src/types/printing";

export default function App() {
  const [document, setDocument] = useState<PrintDocument | null>(null);
  const [color, setColor] = useState<PrintColorMode>("COLOR");
  const [duplex, setDuplex] = useState<DuplexMode>("SIMPLEX");
  const [copies, setCopies] = useState(1);
  const [pagesForDemo, setPagesForDemo] = useState(10);

  const plan = useMemo(() => planManualDuplex(pagesForDemo), [pagesForDemo]);

  async function pick() {
    const result = await DocumentPicker.getDocumentAsync({
      type: ["application/pdf", "image/*", "text/plain"],
      multiple: false,
      copyToCacheDirectory: true,
    });
    if (!result.canceled) setDocument(createDocumentFromPicker(result.assets[0]));
  }

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <ScrollView contentContainerStyle={styles.page}>
        <Text style={styles.brand}>PrintBridge</Text>
        <Text style={styles.title}>Smart Printing</Text>
        <Text style={styles.sub}>One app • wired + wireless</Text>

        <Card title="Document">
          <Pressable style={styles.primary} onPress={pick}>
            <Text style={styles.primaryText}>{document ? "Change document" : "Choose PDF / document"}</Text>
          </Pressable>
          {document && <Text style={styles.muted}>{document.name} • {document.type}</Text>}
        </Card>

        <Card title="Printer connections">
          <Text style={styles.muted}>USB/OTG • Wi‑Fi/LAN • Wi‑Fi Direct • Bluetooth</Text>
          <Pressable style={styles.secondary} onPress={() => Alert.alert("Transport layer", getAvailableTransports().join("\n"))}>
            <Text style={styles.secondaryText}>Show transport capabilities</Text>
          </Pressable>
        </Card>

        <Card title="Print settings">
          <Text style={styles.label}>Color</Text>
          <Segment value={color} items={["COLOR", "MONOCHROME"]} onChange={(v) => setColor(v as PrintColorMode)} />
          <Text style={styles.label}>Duplex</Text>
          <Segment value={duplex} items={["SIMPLEX", "DUPLEX_AUTO", "DUPLEX_MANUAL"]} onChange={(v) => setDuplex(v as DuplexMode)} />
          <Text style={styles.label}>Copies: {copies}</Text>
          <View style={styles.row}>
            <Pressable style={styles.step} onPress={() => setCopies(Math.max(1, copies - 1))}><Text>−</Text></Pressable>
            <Pressable style={styles.step} onPress={() => setCopies(Math.min(99, copies + 1))}><Text>+</Text></Pressable>
          </View>
        </Card>

        <Card title="Smart manual duplex">
          <Text style={styles.muted}>Physical-sheet planner • test pages: {pagesForDemo}</Text>
          <View style={styles.row}>
            <Pressable style={styles.step} onPress={() => setPagesForDemo(Math.max(1, pagesForDemo - 1))}><Text>−</Text></Pressable>
            <Text style={styles.counter}>{pagesForDemo}</Text>
            <Pressable style={styles.step} onPress={() => setPagesForDemo(Math.min(200, pagesForDemo + 1))}><Text>+</Text></Pressable>
          </View>
          <Text style={styles.plan}>{plan.summary}</Text>
          <Text style={styles.note}>The planner reasons in physical sheets, including blank backs and output-stack reversal. Printer-specific feed behavior is a separate capability.</Text>
        </Card>

        <Card title="Project status">
          <Text style={styles.success}>Integrated architecture • Stages 1–15</Text>
          <Text style={styles.muted}>Hardware transport adapters require real-printer validation.</Text>
        </Card>
      </ScrollView>
    </SafeAreaView>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return <View style={styles.card}><Text style={styles.cardTitle}>{title}</Text>{children}</View>;
}

function Segment({ items, value, onChange }: { items: string[]; value: string; onChange: (v: string) => void }) {
  return <View style={styles.segmentRow}>{items.map((item) => <Pressable key={item} style={[styles.segment, item === value && styles.segmentActive]} onPress={() => onChange(item)}><Text style={[styles.segmentText, item === value && styles.segmentTextActive]}>{item.replaceAll("_", " ")}</Text></Pressable>)}</View>;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#F5F7FA" },
  page: { padding: 20, gap: 14 },
  brand: { fontSize: 36, fontWeight: "900" },
  title: { fontSize: 23, fontWeight: "800" },
  sub: { color: "#667085", marginBottom: 5 },
  card: { backgroundColor: "#fff", borderRadius: 18, padding: 16, gap: 11 },
  cardTitle: { fontSize: 17, fontWeight: "800" },
  primary: { backgroundColor: "#111827", padding: 14, borderRadius: 12, alignItems: "center" },
  primaryText: { color: "#fff", fontWeight: "800" },
  secondary: { borderWidth: 1, borderColor: "#D0D5DD", padding: 12, borderRadius: 12, alignItems: "center" },
  secondaryText: { fontWeight: "700" },
  muted: { color: "#667085", lineHeight: 20 },
  label: { fontSize: 13, fontWeight: "800", color: "#475467" },
  segmentRow: { flexDirection: "row", flexWrap: "wrap", gap: 7 },
  segment: { borderWidth: 1, borderColor: "#D0D5DD", borderRadius: 10, paddingVertical: 9, paddingHorizontal: 10 },
  segmentActive: { borderColor: "#2563EB", backgroundColor: "#EEF4FF" },
  segmentText: { fontSize: 12, color: "#475467" },
  segmentTextActive: { color: "#1D4ED8", fontWeight: "800" },
  row: { flexDirection: "row", alignItems: "center", gap: 10 },
  step: { borderWidth: 1, borderColor: "#D0D5DD", borderRadius: 10, padding: 11, minWidth: 44, alignItems: "center" },
  counter: { fontSize: 18, fontWeight: "800", minWidth: 35, textAlign: "center" },
  plan: { fontWeight: "700", lineHeight: 21 },
  note: { color: "#B54708", fontSize: 12, lineHeight: 18 },
  success: { fontWeight: "800" },
});
