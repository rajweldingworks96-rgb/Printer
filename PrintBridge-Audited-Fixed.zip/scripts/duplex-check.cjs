function planManualDuplex(totalPages) {
  const safePages = Math.max(0, Math.floor(totalPages));
  const totalSheets = Math.ceil(safePages / 2);
  const sheets = [];
  for (let sheet = 1; sheet <= totalSheets; sheet++) {
    const front = sheet * 2 - 1;
    const back = sheet * 2 <= safePages ? sheet * 2 : 0;
    sheets.push({ sheet, front, back });
  }
  const firstPass = sheets.map(s => s.front).filter(p => p > 0);
  const secondPass = sheets.map(s => s.back).filter(p => p > 0);
  return { totalSheets, firstPass, secondPass, secondPassReversedForStack: [...secondPass].reverse(), sheets };
}

function equal(a,b){ return JSON.stringify(a)===JSON.stringify(b); }
const cases = [
  [10, 5, [1,3,5,7,9], [2,4,6,8,10], [10,8,6,4,2]],
  [1, 1, [1], [], []],
  [4, 2, [1,3], [2,4], [4,2]],
  [0, 0, [], [], []],
];
for (const [n,sheets,first,second,reversed] of cases) {
  const p=planManualDuplex(n);
  if (p.totalSheets!==sheets || !equal(p.firstPass,first) || !equal(p.secondPass,second) || !equal(p.secondPassReversedForStack,reversed)) {
    console.error("FAIL", n, p);
    process.exit(1);
  }
}
console.log("PASS: duplex planner cases");
