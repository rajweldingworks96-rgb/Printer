import { planManualDuplex } from "../src/core/duplex/ManualDuplexEngine";

test("10 pages maps to 5 sheets", () => {
  const p = planManualDuplex(10);
  expect(p.totalSheets).toBe(5);
  expect(p.firstPass).toEqual([1,3,5,7,9]);
  expect(p.secondPass).toEqual([2,4,6,8,10]);
  expect(p.secondPassReversedForStack).toEqual([10,8,6,4,2]);
});

test("1 page has a blank back", () => {
  const p = planManualDuplex(1);
  expect(p.sheets).toEqual([{ sheet: 1, front: 1, back: 0 }]);
  expect(p.secondPass).toEqual([]);
});

test("4 pages maps to two physical sheets", () => {
  const p = planManualDuplex(4);
  expect(p.sheets).toEqual([
    { sheet: 1, front: 1, back: 2 },
    { sheet: 2, front: 3, back: 4 },
  ]);
});
