# PrintBridge

PrintBridge is an Android-first mobile printing application architecture designed for:
- PDF/document selection and preview
- USB/OTG, Wi-Fi/LAN, Wi-Fi Direct and Bluetooth printer transports
- print settings and queue management
- automatic duplex when the printer reports duplex capability
- smart manual duplex planning based on physical sheets and stack orientation
- printer/job history and robust error reporting

## Important hardware note
Printer hardware is not a single universal protocol. Android's system Print Framework can cover many network printers, while direct USB/OTG and some Bluetooth printers require printer-specific protocols/drivers. PrintBridge therefore isolates transports and capabilities instead of pretending every printer is universally compatible.

## Development
This project uses Expo/React Native with TypeScript and an Android-native bridge boundary for hardware transports.

```bash
npm install
npx expo start
```

For Android native development:

```bash
npx expo prebuild
npx expo run:android
```

Type check:

```bash
npm run typecheck
```

## Stages
All 15 planned stages are represented in this integrated project. Hardware-specific implementations are capability-driven and must be validated against real printer models before claiming universal support.

## Audit status

The project was statically audited after generation:
- JSON/package configuration parses correctly.
- TypeScript/TSX source transpiles without syntax diagnostics.
- The duplex planner has deterministic Node checks for 0, 1, 4 and 10 pages.
- The test command is dependency-light and does not require Jest.
- No binary/executable payloads are included; the archive contains source, config and documentation.

A real Android build and real-printer hardware test still require installing dependencies and using an Android build environment with a physical printer.
